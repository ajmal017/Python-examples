# Stock_Prices_EDA
This project analyzes Stock data of various Financial firms from the year 2006-2015. We identify some interesting patterns from the stock data and try to connect them with various events during that period of time including the Recession of 2008.
